# ⏳ Interview material — PENDING

Stage 0 needs the two primary-evidence files below. They are not yet in the repo.

## Drop here
1. **SSY meeting transcript** → save as:
   `069-2026-06-16-ssy-1st-stage-interview-transcript.md`
2. **Job spec** (offshore broking platform; "AI-First Thinking" section) → save as:
   `SSY-JOB-SPEC.md`

## Until they exist
Stage 0 treats every claim derived from the transcript or the job spec as
`UNVERIFIED — interview material pending`. It must NOT invent their contents.

Once added, re-run Stage 0 (or have it re-read this folder) to upgrade those
findings from `UNVERIFIED` to `CONFIRMED`.
